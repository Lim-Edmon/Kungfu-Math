/**
 * Kungfu Math — App entry point.
 * Author: Lim Edmon · See src/App.tsx for full disclaimer.
 */

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.tsx';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

/** Daftarkan Service Worker (PWA) */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => {
      console.warn('SW gagal didaftarkan:', err);
    });
  });
}
