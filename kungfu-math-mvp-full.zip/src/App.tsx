/**
 * Kungfu Math — Root component (Home / Game / Settings / Result / Dojo).
 * ---------------------------------------------------------------------
 * Author       : Lim Edmon
 * Built with   : AI coding partners (including Grok / xAI and others),
 *                as development assistants — final product owned by author
 * Created      : September 2026
 * Project type : Personal educational game (consumer / community)
 *
 * Disclaimer:
 * This code is provided as-is for the Kungfu Math learning game. It has
 * not been audited for production-grade security or reliability, and it
 * is NOT intended for handling payments, sensitive personal data, or any
 * safety-critical use. Feel free to use, modify, and learn from it for
 * this project — please keep this author credit if you copy or
 * redistribute any part of it elsewhere.
 * ---------------------------------------------------------------------
 */

import { useState, useEffect } from 'react';
import Home, { type PlayKind } from './pages/Home';
import Game from './pages/Game';
import Settings from './pages/Settings';
import Dojo from './pages/Dojo';
import Footer from './components/Footer';
import BottomNav, { type NavTab } from './components/BottomNav';
import type { ArenaStyle, CharacterId, InputMode } from './lib/types';
import type { DifficultyLevel } from './lib/levels';
import { getLevelById } from './lib/levels';
import { loadProgress, recordGameResult, updateProgress } from './lib/storage';
import { getCityById, getNextCityId, getAdventureDifficulty } from './lib/adventure';
import './styles/theme.css';
import './App.css';

type Screen = 'home' | 'game' | 'result' | 'settings' | 'dojo';

function resultHeadline(
  grade: string,
  isNewRecord: boolean,
  score: number,
  opts?: { passedCity?: boolean; cityName?: string }
): { title: string; sub: string; tone: string } {
  if (isNewRecord) {
    return {
      title: 'Rekor baru!',
      sub: 'Kamu pecahkan rekor sendiri. Hebat!',
      tone: 'record',
    };
  }
  if (opts?.passedCity) {
    return {
      title: 'Kota berhasil!',
      sub: opts.cityName
        ? `Target ${opts.cityName} tercapai. Siap jalan lagi?`
        : 'Target kota tercapai. Siap jalan lagi?',
      tone: 'great',
    };
  }
  if (grade === 'S' || grade === 'A') {
    return {
      title: 'Keren banget!',
      sub: 'Hitunganmu sudah jago, pendekar!',
      tone: 'great',
    };
  }
  if (grade === 'B') {
    return {
      title: 'Bagus semangat!',
      sub: 'Sudah bagus. Coba sekali lagi biar lebih tinggi!',
      tone: 'good',
    };
  }
  if (score <= 0) {
    return {
      title: 'Waktu habis!',
      sub: 'Tidak apa-apa. Yuk coba lagi!',
      tone: 'try',
    };
  }
  return {
    title: 'Sudah berusaha!',
    sub: 'Tetap semangat. Latihan lagi, pasti naik!',
    tone: 'try',
  };
}

function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [selectedMode, setSelectedMode] = useState<InputMode>('slice');
  const [selectedArena, setSelectedArena] = useState<ArenaStyle>('static');
  const [playKind, setPlayKind] = useState<PlayKind>('latihan');
  const [adventureDiffId, setAdventureDiffId] = useState('normal');
  const [adventureUnlockedMsg, setAdventureUnlockedMsg] = useState('');
  const [passedCity, setPassedCity] = useState(false);
  const [nextCityId, setNextCityId] = useState<string | null>(null);
  const [lastCityId, setLastCityId] = useState('jakarta');
  const [homePlayKind, setHomePlayKind] = useState<PlayKind | undefined>(undefined);
  const [selectedCharacterId, setSelectedCharacterId] =
    useState<CharacterId | null>(null);
  const [selectedLevel, setSelectedLevel] =
    useState<DifficultyLevel>('pemula');
  const [lastScore, setLastScore] = useState(0);
  const [lastGrade, setLastGrade] = useState('C');
  const [lastHighScore, setLastHighScore] = useState(0);
  const [isNewRecord, setIsNewRecord] = useState(false);

  // Tema & preferensi dari localStorage saat app dibuka (bukan hanya di Home)
  useEffect(() => {
    const p = loadProgress();
    document.documentElement.setAttribute(
      'data-theme',
      p.displayMode || 'siang'
    );
    setSelectedMode(p.preferredMode || 'slice');
    setSelectedLevel(p.preferredLevel || 'pemula');
    if (p.preferredCharacter) {
      setSelectedCharacterId(p.preferredCharacter);
    }
  }, []);

  const handleStartGame = (
    mode: InputMode,
    characterId: CharacterId,
    level: DifficultyLevel,
    arena: ArenaStyle = 'static',
    kind: PlayKind = 'latihan',
    diffId: string = 'normal'
  ) => {
    setSelectedMode(mode);
    setSelectedArena(arena);
    setSelectedCharacterId(characterId);
    setSelectedLevel(level);
    setPlayKind(kind);
    setAdventureDiffId(diffId || 'normal');
    setAdventureUnlockedMsg('');
    setScreen('game');
  };

  const handleExitGame = () => {
    // Dari petualangan → langsung tampil peta petualangan di Home
    if (playKind === 'petualangan') {
      setHomePlayKind('petualangan');
    } else {
      setHomePlayKind(undefined);
    }
    setScreen('home');
  };

  const handleContinueNextCity = () => {
    if (!nextCityId || !selectedCharacterId) return;
    updateProgress({ adventureCityId: nextCityId });
    setAdventureUnlockedMsg('');
    setPassedCity(false);
    setScreen('game');
  };

  const handleBackToAdventureMap = () => {
    setHomePlayKind('petualangan');
    setScreen('home');
  };

  const handleFinishGame = (score: number, grade: string) => {
    const { highScore, isNewRecord: neu } = recordGameResult(
      selectedLevel,
      score
    );
    setLastScore(score);
    setLastGrade(grade);
    setLastHighScore(highScore);
    setIsNewRecord(neu);
    setPassedCity(false);
    setNextCityId(null);

    if (playKind === 'petualangan') {
      const prog = loadProgress();
      const cityId = prog.adventureCityId || 'jakarta';
      setLastCityId(cityId);
      const city = getCityById(cityId);
      const prevHs = prog.adventureHighScores?.[cityId] ?? 0;
      const best = Math.max(prevHs, score);
      const ahs = { ...(prog.adventureHighScores || {}), [cityId]: best };
      let unlocked = [...(prog.adventureUnlocked || ['jakarta'])];
      if (!unlocked.includes('jakarta')) unlocked = ['jakarta', ...unlocked];
      let msg = '';
      let nextId: string | null = null;
      let passed = false;
      if (score >= city.targetScore) {
        passed = true;
        nextId = getNextCityId(cityId);
        if (nextId && !unlocked.includes(nextId)) {
          unlocked = [...unlocked, nextId];
          msg = `Kota baru terbuka: ${getCityById(nextId).nameId}!`;
        } else if (!nextId) {
          msg = 'Semua kota di jalur ini sudah dijelajahi. Hebat!';
        } else {
          msg = `Target ${city.nameId} tercapai!`;
        }
      } else {
        msg = `Belum sampai target ${city.targetScore}. Coba lagi di ${city.nameId}!`;
      }
      updateProgress({
        adventureHighScores: ahs,
        adventureUnlocked: unlocked,
      });
      setAdventureUnlockedMsg(msg);
      setPassedCity(passed);
      setNextCityId(nextId);
    }

    setScreen('result');
  };

  const handlePlayAgain = () => {
    if (selectedCharacterId) {
      setScreen('game');
    } else {
      setScreen('home');
    }
  };

  const handleNav = (tab: NavTab) => {
    if (tab === 'home') setScreen('home');
    else if (tab === 'dojo') setScreen('dojo');
    else setScreen('settings');
  };

  const navActive: NavTab =
    screen === 'settings' ? 'settings' : screen === 'dojo' ? 'dojo' : 'home';

  const showChrome = screen !== 'game';
  const levelLabel = getLevelById(selectedLevel).labelId;

  return (
    <div
      className={`app ${screen === 'game' ? 'is-game' : ''} ${
        showChrome ? 'has-bottom-nav' : ''
      }`}
    >
      <main className="app-main">
        {screen === 'home' && <Home onStartGame={handleStartGame} initialPlayKind={homePlayKind} />}

        {screen === 'dojo' && <Dojo />}

        {screen === 'settings' && (
          <Settings onBack={() => setScreen('home')} />
        )}

        {screen === 'game' && selectedCharacterId && (
          <Game
            mode={selectedMode}
            characterId={selectedCharacterId}
            level={selectedLevel}
            agility={selectedArena === 'agility'}
            timeBonusSec={
              playKind === 'petualangan'
                ? getAdventureDifficulty(adventureDiffId).timeBonus
                : 0
            }
            cityName={
              playKind === 'petualangan'
                ? getCityById(loadProgress().adventureCityId || 'jakarta').nameId
                : undefined
            }
            cityId={
              playKind === 'petualangan'
                ? loadProgress().adventureCityId || 'jakarta'
                : undefined
            }
            targetScore={
              playKind === 'petualangan'
                ? getCityById(loadProgress().adventureCityId || 'jakarta')
                    .targetScore
                : undefined
            }
            onExit={handleExitGame}
            onFinish={handleFinishGame}
          />
        )}

        {screen === 'result' && (() => {
          const city =
            playKind === 'petualangan' ? getCityById(lastCityId) : null;
          const nextCity = nextCityId ? getCityById(nextCityId) : null;
          const headline = resultHeadline(lastGrade, isNewRecord, lastScore, {
            passedCity: playKind === 'petualangan' && passedCity,
            cityName: city?.nameId,
          });
          const celebrate =
            isNewRecord ||
            passedCity ||
            lastGrade === 'S' ||
            lastGrade === 'A';
          return (
            <div className={`result-screen tone-${headline.tone}`}>
              {celebrate && (
                <div className="result-confetti" aria-hidden>
                  <span>🎉</span>
                  <span>✨</span>
                  <span>🎊</span>
                  <span>⭐</span>
                  <span>🏆</span>
                  <span>💫</span>
                  <span>🎈</span>
                  <span>🌟</span>
                </div>
              )}
              <div className="result-burst" aria-hidden>
                {celebrate ? '🎉✨🏆' : lastGrade === 'B' ? '⭐👏' : '💪🌟'}
              </div>
              <p className="result-float-title">{headline.title}</p>
              <p className="result-float-sub">{headline.sub}</p>
              {adventureUnlockedMsg && (
                <p className="result-adventure">{adventureUnlockedMsg}</p>
              )}
              <p className="result-level">
                {playKind === 'petualangan' && city
                  ? `Petualangan · ${city.nameId}`
                  : `Level: ${levelLabel}`}
              </p>
              <p className="result-grade">Nilai: {lastGrade}</p>
              <p className="result-score">Skor: {lastScore}</p>
              {playKind === 'petualangan' && city && (
                <p className="result-high">
                  Target kota: {city.targetScore}
                  {passedCity ? ' ✓ tercapai' : ' · belum tercapai'}
                </p>
              )}
              <p className="result-high">
                Rekor terbaik: {lastHighScore}
                {isNewRecord ? ' · rekor baru!' : ''}
              </p>
              <div className="result-actions">
                {playKind === 'petualangan' && passedCity && nextCity && (
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={handleContinueNextCity}
                  >
                    Lanjut ke {nextCity.nameId}
                  </button>
                )}
                <button
                  type="button"
                  className="btn-primary"
                  onClick={handlePlayAgain}
                >
                  {playKind === 'petualangan' && city
                    ? `Main lagi di ${city.nameId}`
                    : 'Main lagi'}
                </button>
                {playKind === 'petualangan' ? (
                  <button
                    type="button"
                    className="btn-ghost"
                    onClick={handleBackToAdventureMap}
                  >
                    Kembali ke peta
                  </button>
                ) : (
                  <button
                    type="button"
                    className="btn-ghost"
                    onClick={handleExitGame}
                  >
                    Kembali ke Latihan
                  </button>
                )}
                <button
                  type="button"
                  className="btn-ghost"
                  onClick={() => setScreen('dojo')}
                >
                  Lihat Dojo
                </button>
              </div>
            </div>
          );
        })()}
      </main>

      {showChrome && (
        <>
          <Footer />
          <BottomNav active={navActive} onChange={handleNav} />
        </>
      )}
    </div>
  );
}

export default App;
