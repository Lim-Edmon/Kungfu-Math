/** Kungfu Math — Author: Lim Edmon · Full disclaimer: src/App.tsx */

import type { CharacterId, InputMode } from './types';
import type { MathQuestion } from './mathGenerator';

export type GameStatus = 'countdown' | 'playing' | 'paused' | 'won' | 'lost';

export interface FloatingNumber {
  id: string;
  value: number;
  x: number; // 0–100 (%)
  y: number; // 0–100 (%)
  isBomb: boolean;
  sliced: boolean;
  /** Kecepatan mode ketangkasan (% arena per detik) */
  vx?: number;
  vy?: number;
  /**
   * Mode Pass: peran bola saat di arena.
   * 'answer' = bagian jalur jawaban aktif (boleh berganti saat di-respawn).
   * 'decoy' = pengalih perhatian.
   */
  passRole?: 'answer' | 'decoy';
}

export interface GameState {
  status: GameStatus;
  mode: InputMode;
  characterId: CharacterId;
  lives: number;
  score: number;
  combo: number;
  maxCombo: number;
  timeLeft: number; // detik
  question: MathQuestion | null;
  numbers: FloatingNumber[];
  /** id bola yang sudah dipilih di soal ini (anti double-tap) */
  selectedIds: string[];
  /** Nilai yang sudah dipilih — disimpan terpisah agar bola bisa hilang visual */
  selectedValues: number[];
  questionsSolved: number;
  stage: number;
}

export const INITIAL_LIVES = 3;
export const ROUND_SECONDS = 60;
export const POINTS_PER_SOLVE = 100;
/** Bonus per tingkat combo: diam +5, bergerak +10 */
export const COMBO_BONUS_STATIC = 5;
export const COMBO_BONUS_AGILITY = 10;
/** @deprecated pakai COMBO_BONUS_STATIC / AGILITY */
export const COMBO_BONUS = 5;


/** Pengali skor (bisa ditumpuk). Lihat docs/SCORING.md
 * Tempo mudah = poin per jawaban lebih murah; Berani = lebih padat. */
export const TEMPO_SCORE_MULT: Record<string, number> = {
  santai: 0.95,
  ringan: 0.98,
  normal: 1.0,
  berani: 1.1,
};

export const LEVEL_SCORE_MULT: Record<string, number> = {
  pemula: 1.0,
  dasar: 1.05,
  menengah: 1.1,
  mahir: 1.15,
  master: 1.2,
};

export const AGILITY_SCORE_MULT = 1.1;
/** Pass lebih sulit (pair bisa berganti) — +0.1 vs bounce */
export const PASS_SCORE_MULT = 1.2;
export const STATIC_SCORE_MULT = 1.0;

/** Tap (tangan kosong) sedikit lebih tinggi dari slice */
export const TAP_SCORE_MULT = 1.05;
export const SLICE_SCORE_MULT = 1.0;

/** Jawab benar < 1 detik sejak soal muncul, tanpa salah di soal itu */
export const SPEED_SCORE_MULT = 1.1;
export const SPEED_BONUS_MS = 1000;

/** Focus ops: add/sub only 1.0; mixed with mul/div 1.05; mul/div only 1.1; full/random = 1.0 */
export function opsScoreMultiplier(
  forceOps?: Array<'add' | 'sub' | 'mul' | 'div'> | null
): number {
  if (!forceOps || forceOps.length === 0) return 1.0;
  const set = new Set(forceOps);
  const hasEasy = set.has('add') || set.has('sub');
  const hasHard = set.has('mul') || set.has('div');
  if (hasHard && !hasEasy) return 1.1;
  if (hasHard && hasEasy) return 1.05;
  return 1.0;
}

export function computeSolvePoints(opts: {
  combo: number;
  /** true = bola gerak (bounce/pass) — combo bonus lebih tinggi */
  agility: boolean;
  /** static | agility (bounce) | pass — pengali arena */
  arenaStyle?: 'static' | 'agility' | 'pass' | null;
  tempoId?: string | null;
  levelId?: string | null;
  forceOps?: Array<'add' | 'sub' | 'mul' | 'div'> | null;
  /** true = jawab benar < SPEED_BONUS_MS tanpa salah di soal ini */
  fastSolve?: boolean;
  /** slice | tap — tap ×1.05 */
  inputMode?: 'slice' | 'tap' | null;
}): number {
  const comboBonus = opts.agility ? COMBO_BONUS_AGILITY : COMBO_BONUS_STATIC;
  const raw =
    POINTS_PER_SOLVE +
    (opts.combo > 1 ? (opts.combo - 1) * comboBonus : 0);
  const tempoMul = TEMPO_SCORE_MULT[opts.tempoId || ''] ?? 1.0;
  const levelMul = LEVEL_SCORE_MULT[opts.levelId || ''] ?? 1.0;
  const style = opts.arenaStyle ?? (opts.agility ? 'agility' : 'static');
  const arenaMul =
    style === 'pass'
      ? PASS_SCORE_MULT
      : style === 'agility'
        ? AGILITY_SCORE_MULT
        : STATIC_SCORE_MULT;
  const opsMul = opsScoreMultiplier(opts.forceOps);
  const speedMul = opts.fastSolve ? SPEED_SCORE_MULT : 1.0;
  const inputMul =
    opts.inputMode === 'tap' ? TAP_SCORE_MULT : SLICE_SCORE_MULT;
  return Math.round(
    raw * tempoMul * levelMul * arenaMul * opsMul * speedMul * inputMul
  );
}
