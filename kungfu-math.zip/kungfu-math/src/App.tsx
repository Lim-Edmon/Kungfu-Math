import { useState } from 'react';
import Home from './pages/Home';
import type { InputMode } from './lib/types';
import './styles/theme.css';
import './App.css';

type Screen = 'home' | 'game' | 'result';

function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [selectedMode, setSelectedMode] = useState<InputMode>('slice');

  const handleStartGame = (mode: InputMode) => {
    setSelectedMode(mode);
    // Untuk Fase 0: belum ada game screen, tampilkan pesan dulu
    setScreen('game');
  };

  const handleBackToHome = () => {
    setScreen('home');
  };

  return (
    <div className="app">
      {screen === 'home' && <Home onStartGame={handleStartGame} />}

      {screen === 'game' && (
        <div className="placeholder-screen">
          <h2>Mode: {selectedMode === 'slice' ? 'Slice ⚔️' : 'Tap 👊'}</h2>
          <p>
            Gameplay akan dibangun di <strong>Fase 1</strong>.
          </p>
          <p>Fondasi (Fase 0) sudah siap!</p>
          <button className="btn-primary" onClick={handleBackToHome}>
            Kembali ke Home
          </button>
        </div>
      )}
    </div>
  );
}

export default App;
