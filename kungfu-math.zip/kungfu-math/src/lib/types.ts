/** Tipe data utama untuk Kungfu Math */

export type InputMode = 'slice' | 'tap';

export type DisplayMode = 'siang' | 'malam' | 'nyaman';

export type CharacterId =
  | 'hong-yi'
  | 'ming-zhe'
  | 'ling-yun'
  | 'an-ning'
  | 'zhi-xing'
  | 'qing-lan';

export interface Character {
  id: CharacterId;
  name: string;
  nicknameId: string; // key untuk julukan (akan diganti sesuai bahasa)
  nicknameEn: string;
  gender: 'male' | 'female';
  mode: InputMode; // slice = bersenjata, tap = tangan kosong
  weapon?: string; // hanya untuk slice
  style?: string; // hanya untuk tap
}

export interface PlayerProgress {
  highScores: Record<number, number>; // stage -> skor tertinggi
  unlockedStages: number[];
  preferredMode: InputMode;
  preferredCharacter: CharacterId;
  displayMode: DisplayMode;
  isSubscribed: boolean;
  soundMuted: boolean;
  totalGamesPlayed: number;
  language: 'id' | 'en';
}

export const DEFAULT_PROGRESS: PlayerProgress = {
  highScores: {},
  unlockedStages: [1, 2, 3, 4, 5], // fase testing: semua terbuka
  preferredMode: 'slice',
  preferredCharacter: 'hong-yi',
  displayMode: 'siang',
  isSubscribed: false,
  soundMuted: false,
  totalGamesPlayed: 0,
  language: 'id',
};
