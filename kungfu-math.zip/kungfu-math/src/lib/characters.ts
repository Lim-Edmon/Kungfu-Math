import type { Character } from './types';

/** Daftar karakter Kungfu Math (versi imut/chibi) */
export const CHARACTERS: Character[] = [
  // === Mode Slice (bersenjata) ===
  {
    id: 'hong-yi',
    name: 'Hong Yi',
    nicknameId: 'Tongkat Teguh',
    nicknameEn: 'Steadfast Staff',
    gender: 'male',
    mode: 'slice',
    weapon: 'tongkat',
  },
  {
    id: 'ming-zhe',
    name: 'Ming Zhe',
    nicknameId: 'Pedang Bijak',
    nicknameEn: 'Wise Blade',
    gender: 'male',
    mode: 'slice',
    weapon: 'pedang',
  },
  {
    id: 'ling-yun',
    name: 'Ling Yun',
    nicknameId: 'Tombak Awan',
    nicknameEn: 'Cloud Spear',
    gender: 'female',
    mode: 'slice',
    weapon: 'tombak',
  },

  // === Mode Tap (tangan kosong) ===
  {
    id: 'an-ning',
    name: 'An Ning',
    nicknameId: 'Tinju Damai',
    nicknameEn: 'Peaceful Fist',
    gender: 'male',
    mode: 'tap',
    style: 'shaolin',
  },
  {
    id: 'zhi-xing',
    name: 'Zhi Xing',
    nicknameId: 'Telapak Sakti',
    nicknameEn: 'Knowing Palm',
    gender: 'male',
    mode: 'tap',
    style: 'telapak',
  },
  {
    id: 'qing-lan',
    name: 'Qing Lan',
    nicknameId: 'Tendangan Angin',
    nicknameEn: 'Mist Kick',
    gender: 'female',
    mode: 'tap',
    style: 'tendangan',
  },
];

/** Ambil karakter berdasarkan mode */
export function getCharactersByMode(mode: 'slice' | 'tap'): Character[] {
  return CHARACTERS.filter((c) => c.mode === mode);
}

/** Ambil karakter default untuk mode tertentu */
export function getDefaultCharacter(mode: 'slice' | 'tap'): Character {
  if (mode === 'slice') {
    return CHARACTERS.find((c) => c.id === 'hong-yi')!;
  }
  return CHARACTERS.find((c) => c.id === 'an-ning')!;
}

/** Ambil satu karakter by id */
export function getCharacterById(id: string): Character | undefined {
  return CHARACTERS.find((c) => c.id === id);
}
