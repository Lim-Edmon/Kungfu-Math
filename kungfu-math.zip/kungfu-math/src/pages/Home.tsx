import { useState, useEffect } from 'react';
import type { DisplayMode, InputMode } from '../lib/types';
import { loadProgress, updateProgress } from '../lib/storage';
import { getCharactersByMode, getDefaultCharacter } from '../lib/characters';

interface HomeProps {
  onStartGame: (mode: InputMode) => void;
}

export default function Home({ onStartGame }: HomeProps) {
  const [mode, setMode] = useState<InputMode>('slice');
  const [displayMode, setDisplayMode] = useState<DisplayMode>('siang');
  const [ready, setReady] = useState(false);

  // Load preferensi saat pertama kali
  useEffect(() => {
    const progress = loadProgress();
    setMode(progress.preferredMode);
    setDisplayMode(progress.displayMode);
    document.documentElement.setAttribute('data-theme', progress.displayMode);
    setReady(true);
  }, []);

  // Ganti mode tampilan
  const handleDisplayChange = (newMode: DisplayMode) => {
    setDisplayMode(newMode);
    document.documentElement.setAttribute('data-theme', newMode);
    updateProgress({ displayMode: newMode });
  };

  // Ganti mode input (Slice / Tap)
  const handleModeChange = (newMode: InputMode) => {
    setMode(newMode);
    const defaultChar = getDefaultCharacter(newMode);
    updateProgress({
      preferredMode: newMode,
      preferredCharacter: defaultChar.id,
    });
  };

  const characters = getCharactersByMode(mode);

  if (!ready) {
    return (
      <div className="loading-screen">
        <p>Memuat Kungfu Math...</p>
      </div>
    );
  }

  return (
    <div className="home-page">
      {/* Header */}
      <header className="home-header">
        <h1 className="logo">Kungfu Math</h1>
        <p className="tagline">Latih hitung cepat ala pendekar!</p>
      </header>

      {/* Pilih Mode Input */}
      <section className="mode-section">
        <h2>Pilih Cara Main</h2>
        <div className="mode-buttons">
          <button
            className={`mode-btn ${mode === 'slice' ? 'active' : ''}`}
            onClick={() => handleModeChange('slice')}
          >
            <span className="mode-icon">⚔️</span>
            <span className="mode-name">Slice</span>
            <span className="mode-desc">Geser untuk tebas</span>
          </button>
          <button
            className={`mode-btn ${mode === 'tap' ? 'active' : ''}`}
            onClick={() => handleModeChange('tap')}
          >
            <span className="mode-icon">👊</span>
            <span className="mode-name">Tap</span>
            <span className="mode-desc">Tekan angka yang benar</span>
          </button>
        </div>
      </section>

      {/* Karakter sesuai mode */}
      <section className="character-section">
        <h2>Pendekar {mode === 'slice' ? 'Bersenjata' : 'Tangan Kosong'}</h2>
        <div className="character-list">
          {characters.map((char) => (
            <div key={char.id} className="character-card">
              <div className="character-avatar">
                {char.gender === 'female' ? '👧' : '👦'}
              </div>
              <div className="character-info">
                <strong>{char.name}</strong>
                <span>{char.nicknameId}</span>
              </div>
            </div>
          ))}
        </div>
        <p className="character-note">
          (Pilihan karakter detail akan muncul di versi berikutnya)
        </p>
      </section>

      {/* Tombol Mulai */}
      <div className="start-section">
        <button
          className="btn-primary btn-start"
          onClick={() => onStartGame(mode)}
        >
          Mulai Latihan
        </button>
      </div>

      {/* Mode Tampilan */}
      <section className="display-section">
        <h3>Mode Tampilan</h3>
        <div className="display-buttons">
          <button
            className={`display-btn ${displayMode === 'siang' ? 'active' : ''}`}
            onClick={() => handleDisplayChange('siang')}
          >
            ☀️ Siang
          </button>
          <button
            className={`display-btn ${displayMode === 'malam' ? 'active' : ''}`}
            onClick={() => handleDisplayChange('malam')}
          >
            🌙 Malam
          </button>
          <button
            className={`display-btn ${displayMode === 'nyaman' ? 'active' : ''}`}
            onClick={() => handleDisplayChange('nyaman')}
          >
            👁️ Nyaman Mata
          </button>
        </div>
      </section>

      <footer className="home-footer">
        <p>Fase 0 – Fondasi | Semua stage terbuka untuk testing</p>
      </footer>
    </div>
  );
}
